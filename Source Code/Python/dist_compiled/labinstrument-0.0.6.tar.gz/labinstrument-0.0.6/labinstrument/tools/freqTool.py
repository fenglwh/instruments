__Author__="Adair.l@qq.com"

import math
import re
# channel info is used to comment and list all the capability

channel_map={}

def get_information_from_channel_ul():
    pass

def get_information_from_channel_dl():
    pass

def get_information_from_freq_ul():
    pass

def get_information_from_freq_dl():
    pass

def calculate_LTE_freq_offset(bw,rb_allocation,rb_start):
    pass













